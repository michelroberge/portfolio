export interface ParsedJob {
    title: string;
    company: string;
    startDate: string;
    endDate: string;
    description: string;
    location: string;
  }
