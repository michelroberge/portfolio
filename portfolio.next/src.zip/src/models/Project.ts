export interface Project {
    _id: number;
    title: string;
    description: string;
    excerpt?: string;
    link: string;
    tags?: string[];
  }