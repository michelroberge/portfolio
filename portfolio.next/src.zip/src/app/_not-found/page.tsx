export default function NotFound() {
    return (<div>
        <h1>Ooops</h1>
        <p>Could not find anything here.</p>
    </div>);
}